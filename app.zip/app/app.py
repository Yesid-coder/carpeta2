from flask import Flask, render_template, request, redirect, url_for, session
from pymongo import MongoClient
from bson.objectid import ObjectId
from model import Usuario, Medicamento

app = Flask(__name__)
app.secret_key = 'clave_secreta_segura'

# Conexión a MongoDB Atlas
client = MongoClient('mongodb+srv://Neider:Nei%40123.@cluster0.4ipvsze.mongodb.net/')
db = client['medicenter']  # nombre de tu base de datos
usuario_model = Usuario(db['usuarios'])
medicamento_model = Medicamento(db['medicamentos'])

# Colecciones
usuarios = db['usuarios']
medicamentos = db['medicamentos']

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        nombre = request.form['nombre']
        cedula = request.form['cedula']
        
        usuario = usuarios.find_one({"nombre": nombre, "cedula": cedula})
        
        if usuario:
            session['usuario_id'] = str(usuario['_id'])
            session['rol'] = usuario['rol']

            if usuario['rol'] == 'admin':
                return redirect(url_for('admin_panel'))
            else:
                return redirect(url_for('user_panel'))
        else:
            # Redirigir al registro con datos prellenados
            return redirect(url_for('register', nombre=nombre, cedula=cedula))
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    nombre = request.args.get('nombre', '')
    cedula = request.args.get('cedula', '')

    if request.method == 'POST':
        nombre = request.form['nombre']
        cedula = request.form['cedula']

        # Verificar si ya existe (por si vuelve atrás y reenvía)
        if usuarios.find_one({'cedula': cedula}):
            mensaje_error = 'ya hay un ususario con esas credenciales'
            return render_template('register.html', nombre=nombre, cedula=cedula, error=mensaje_error)

        nuevo_usuario = {
            "nombre": nombre,
            "cedula": cedula,
            "rol": "usuario",
            "medicamento": None
        }

        result = usuarios.insert_one(nuevo_usuario)
        session['usuario_id'] = str(result.inserted_id)
        session['rol'] = "usuario"
        return redirect(url_for('user_panel'))

    return render_template('register.html', nombre=nombre, cedula=cedula)

@app.route('/usuario')
def user_panel():
    usuario_id = session.get('usuario_id')
    if not usuario_id:
        return redirect(url_for('login'))

    usuario = usuarios.find_one({"_id": ObjectId(usuario_id)})
    return render_template('inicio_de_usuario.html', usuario=usuario)


@app.route('/admin', methods=['GET', 'POST'])
def admin_panel():
    if session.get('rol') != 'admin':
        return redirect(url_for('login'))

    if request.method == 'POST':
        usuario_id = request.form['usuario_id']
        medicamento_id = request.form['medicamento_id']

        # Obtener medicamento por ID
        medicamento = medicamentos.find_one({"_id": ObjectId(medicamento_id)})

        # Asignar medicamento al usuario
        usuarios.update_one(
            {"_id": ObjectId(usuario_id)},
            {"$set": {"medicamento": {
                "nombre": medicamento['nombre'],
                "dosis": medicamento['dosis']
            }}}
        )

    # Obtener lista de usuarios y medicamentos
    lista_usuarios = list(usuarios.find({"rol": "usuario"}))
    lista_medicamentos = list(medicamentos.find())

    return render_template('admin_panel.html', usuarios=lista_usuarios, medicamentos=lista_medicamentos)

@app.route('/admin/medicamentos')
def panel_medicamentos():
    if session.get('rol') != 'admin':
        return redirect(url_for('login'))

    modelo = Medicamento(medicamentos)
    lista = modelo.listar_medicamentos()
    return render_template('medicamentos_panel.html', medicamentos=lista)

@app.route('/admin/agregar_medicamento', methods=['POST'])
def agregar_medicamento():
    if session.get('rol') != 'admin':
        return redirect(url_for('login'))

    nombre = request.form['nombre']
    dosis = request.form['dosis']
    frecuencia = int(request.form['frecuencia'])

    modelo = Medicamento(medicamentos)
    modelo.insertar(nombre, dosis, frecuencia)

    return redirect(url_for('panel_medicamentos'))

@app.route('/admin/eliminar_medicamento/<medicamento_id>', methods=['POST'])
def eliminar_medicamento(medicamento_id):
    if session.get('rol') != 'admin':
        return redirect(url_for('login'))

    modelo = Medicamento(medicamentos)
    modelo.eliminar(medicamento_id)

    return redirect(url_for('panel_medicamentos'))


@app.route('/admin/logout', methods=['POST'])
def admin_logout():
    session.clear()
    return redirect(url_for('login'))


if __name__ == '__main__':
    app.run(debug=True)