# model.py

from bson.objectid import ObjectId

class Usuario:
    def __init__(self, collection):
        self.collection = collection

    def encontrar_por_nombre_cedula(self, nombre, cedula):
        return self.collection.find_one({"nombre": nombre, "cedula": cedula})

    def encontrar_por_id(self, usuario_id):
        return self.collection.find_one({"_id": ObjectId(usuario_id)})

    def insertar(self, nombre, cedula):
        nuevo_usuario = {
            "nombre": nombre,
            "cedula": cedula,
            "rol": "usuario",
            "medicamento": None
        }
        return self.collection.insert_one(nuevo_usuario)

    def asignar_medicamento(self, usuario_id, medicamento):
        self.collection.update_one(
            {"_id": ObjectId(usuario_id)},
            {"$set": {"medicamento": medicamento}}
        )

    def listar_usuarios(self):
        return list(self.collection.find({"rol": "usuario"}))


class Medicamento:
    def __init__(self, collection):
        self.collection = collection

    def encontrar_por_id(self, medicamento_id):
        return self.collection.find_one({"_id": ObjectId(medicamento_id)})

    def listar_medicamentos(self):
        return list(self.collection.find())

    def insertar(self, nombre, dosis, frecuencia):
        nuevo_medicamento = {
            "nombre": nombre,
            "dosis": dosis,
            "frecuencia": frecuencia  # frecuencia en horas
        }
        return self.collection.insert_one(nuevo_medicamento)

    def eliminar(self, medicamento_id):
        return self.collection.delete_one({"_id": ObjectId(medicamento_id)})
